# Hashcode2k22
The official repo of JavariatiTeam - Hashcode 2022 edition
